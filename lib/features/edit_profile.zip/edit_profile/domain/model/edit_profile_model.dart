class EditProfileModel {
  
}