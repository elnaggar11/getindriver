import 'endpoints.dart';

import '../model/edit_profile_model.dart';
import '../../../../core/data_source/dio_helper.dart';

  //put it in locators locator.registerLazySingleton(() => EditProfileRepository(locator<DioService>()));
//  import '../../modules/edit_profile/domain/repository/repository.dart';
class EditProfileRepository{
final  DioService dioService ;
  EditProfileRepository(this.dioService);
}
