
class EditProfileRequest {
  
}