import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:getin_driver/core/extensions/all_extensions.dart';
import 'package:getin_driver/core/theme/light_theme.dart';
import 'package:getin_driver/core/utils/extentions.dart';
import 'package:getin_driver/features/edit_profile/presentation/widgets/edit_profile_image.dart';
import 'package:getin_driver/shared/back_widget.dart';
import 'package:getin_driver/shared/widgets/colored_container.dart';
import 'package:getin_driver/shared/widgets/default_image_widget.dart';
import 'package:getin_driver/shared/widgets/edit_text_widget.dart';
import '../../cubit/edit_profile_cubit.dart';
import '../../cubit/edit_profile_states.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => EditProfileCubit(),
      child: BlocConsumer<EditProfileCubit, EditProfileStates>(
        listener: (context, state) {
          // TODO: implement listener
        },
        builder: (context, state) {
          final cubit = EditProfileCubit.get(context);
          return Scaffold(
            backgroundColor: LightThemeColors.white,
            appBar: AppBar(
              leading: const BackWidget(),
              centerTitle: false,
              title: const Text(
                'Account information',
                style: TextStyle(
                  color: LightThemeColors.primary,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            body: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                const SizedBox(height: 16),
                EditProfileImage(),
                const SizedBox(height: 16),

                SizedBox(
                  height: 60,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: TextFormFieldWidget(
                          fixedlabel: 'First Name *',
                          hintText: 'First Name',
                          onChanged: (value) {},
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: TextFormFieldWidget(
                          fixedlabel: 'Last Name *',
                          hintText: 'Last Name',
                          //   hintText: 'Enter your name',
                          onChanged: (value) {},
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 35),
                TextFormFieldWidget(
                  fixedlabel: 'Phone Number *',
                  hintText: 'Enter your number here',
                  suffixIcon: 'phone'.svg().toSvg(),
                  //   hintText: 'Enter your name',
                  onChanged: (value) {},
                ),
                const SizedBox(height: 35),
                TextFormFieldWidget(
                  fixedlabel: 'Email *',
                  hintText: 'Enter your email here',
                  suffixIcon: 'email'.svg().toSvg(),

                  //   hintText: 'Enter your name',
                  onChanged: (value) {},
                ),
                const SizedBox(height: 35),
                TextFormFieldWidget(
                  fixedlabel: 'Password *',
                  hintText: 'Enter your password here',

                  //   hintText: 'Enter your name',
                  onChanged: (value) {},

                  password: true,
                ),
                const SizedBox(height: 16),
                ColoredContainer(
                  height: 58,
                  color: LightThemeColors.primary,
                  child: Center(
                    child: Text(
                      'save',
                      style: TextStyle(
                        color: LightThemeColors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
